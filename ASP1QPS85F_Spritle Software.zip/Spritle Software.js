function expression(number, operation) {
    console.log('expression');
    if (!operation) return number;
    return operation(number);
}

function five(operation) {
    console.log('five');
    return expression(5, operation);
}

function seven(operation) {
    console.log('seven');
    return expression(7, operation);
}

function times(x) {
    console.log('times');
    return function(y) {
        return y * x;
    }
}

console.log(seven(times(five()))); // 35

console.log([five, times, seven].reduce((value, fn) => fn(value), undefined))